"""
retrieval/base_connector.py — 데이터 커넥터 추상 인터페이스

v2: to_graph_nodes(), tag_provenance() 메서드 추가

[참고] RAG (Lewis et al., NeurIPS 2020) — https://github.com/huggingface/transformers
  검색 → LLM context 주입 패턴. 커넥터의 search→fetch→context 흐름에 참고.
"""
# 수정자: 신준수
# 수정 날짜: 2026-04-27
# 수정 내용: StatData에 official_value·unit·time_period(증거 정규화; 출처 API 키는 커넥터가 채움)
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
from structverify.core.schemas import GraphNode, ProvenanceRecord
from structverify.utils.logger import get_logger

logger = get_logger(__name__)

@dataclass
class ConnectorQuery:
    keyword: str
    indicator: str | None = None
    time_period: str | None = None
    population: str | None = None
    extra_params: dict[str, Any] = field(default_factory=dict)

@dataclass
class StatRecord:
    stat_id: str; stat_name: str; org_name: str; org_id: str | None = None
    available_periods: list[str] = field(default_factory=list)
    relevance_score: float = 0.0
    # 출처별 search 응답 한 행 전체; 커넥터·API별 추가 키는 여기로.
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class StatData:
    stat_id: str; stat_name: str
    values: dict[str, Any] = field(default_factory=dict)
    raw_response: dict[str, Any] = field(default_factory=dict)
    # Evidence/검증용 정규화(커넥터가 출처 API에서 채움; subgraph는 values 키를 직접 보지 않음)
    official_value: float | None = None
    unit: str | None = None
    time_period: str | None = None


class BaseConnector(ABC):
    """
    모든 커넥터의 추상 기본 클래스.
    v2에서 to_graph_nodes()와 tag_provenance() 추가.
    """
    @abstractmethod
    async def search(self, query: ConnectorQuery) -> list[StatRecord]: ...

    @abstractmethod
    async def fetch(self, stat_id: str, params: dict[str, Any]) -> StatData: ...

    @abstractmethod
    def to_graph_nodes(self, data: StatData) -> list[GraphNode]:
        """v2: 조회 결과를 그래프 노드로 변환"""
        ...

    @abstractmethod
    def tag_provenance(self, data: StatData, query: ConnectorQuery) -> ProvenanceRecord:
        """v2: 출처 이력 기록"""
        ...

    async def search_and_fetch(self, query: ConnectorQuery) -> StatData | None:
        records = await self.search(query)
        if not records:
                # ── [v6] LLM Agent 검색어 재생성 ─────────────────────────────────
            simplified = await self._agent_simplify_keyword(query, tried_log)
            if simplified and simplified != (query.indicator or query.keyword or ""):
                logger.info(f"[재검색] Agent 검색어 변경: '{query.keyword}' → '{simplified}'")
                from structverify.retrieval.base_connector import ConnectorQuery
                retry_query = ConnectorQuery(
                    keyword=simplified,
                    indicator=simplified,
                    time_period=query.time_period,
                    population=query.population,
                    extra_params=query.extra_params,
                )
                retry_candidates = await self.catalog.search(retry_query, top_k=5)
                retry_candidates = [c for c in retry_candidates if c.stat_id not in tried_ids]

                for rc in retry_candidates[:3]:
                    if not _is_table_relevant(simplified, rc.stat_name):
                        continue
                    data = await self._fetch_with_retry(
                        stat_id=rc.stat_id, stat_rec=rc, query=query,
                        prd_se_hint="Y",
                        start_prd_de=query.time_period or "",
                        end_prd_de=query.time_period or "",
                    )
                    if data and data.official_value is not None:
                        logger.info(f"[재검색] 성공: [{rc.stat_id}] {rc.stat_name}")
                        return data

            logger.warning(f"최종 Evidence 없음 ({len(tried_ids)}개 시도): {query.keyword}")
            return None
        best = max(records, key=lambda r: r.relevance_score)
        return await self.fetch(
            best.stat_id,
            {
                "time_period": query.time_period,
                "population": query.population,
                "query": query,
                "stat_record": best,
            },
        )
